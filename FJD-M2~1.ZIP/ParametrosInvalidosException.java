
public class ParametrosInvalidosException extends Exception {
    // Classe de teste da Exceção "ParametrosInvalidosException"...
}